
// Placeholder for popup functionalities
document.getElementById('matchBtn').addEventListener('click', () => {
  alert('Finding a Skill Match...');
});

document.getElementById('notifyBtn').addEventListener('click', () => {
  alert('Notifications enabled!');
});

document.getElementById('chatBtn').addEventListener('click', () => {
  alert('Opening chat...');
});
