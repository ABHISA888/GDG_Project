
// Placeholder background script
chrome.runtime.onInstalled.addListener(() => {
  console.log("SkillSwap Extension Installed.");
});
